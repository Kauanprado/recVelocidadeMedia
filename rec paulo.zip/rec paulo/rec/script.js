

function CalcularVelocidade() {
    let deslocamento = document.getElementById("deslocamento")
    let intervalov= document.getElementById("intervalo")
    getelementbyid("deslocamento").value
    getelementbyid("intervalo").value
    resultado.push( "deslocamento" / "intervalo")
   
       document.getElementById("resultado") = resultado
}




    
